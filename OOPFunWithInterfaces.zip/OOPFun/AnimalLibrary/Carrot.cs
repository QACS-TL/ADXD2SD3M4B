﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalLibrary
{
    internal class Carrot : IVegetable
    {
        private int length = 0;
       
        public int Length
        {
            get
            {
                return length;
            }
            set
            {
                length = value;
            }
        }
        public string Colour { get; set; } = "Orange";

        public string Bloom()
        {
            return $"I'm a carrot blooming! I have a bright {Colour} colour and I'm delicious in salads!";
        }

        public int Grow(int amount)
        {
            Length += amount;
            return Length;
        }
    }
}
