﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalLibrary
{
    public interface IVegetable
    {
        int Length { get; set; }
        string Colour { get; set; }

        int Grow(int amount);
        string Bloom();
    }
}
