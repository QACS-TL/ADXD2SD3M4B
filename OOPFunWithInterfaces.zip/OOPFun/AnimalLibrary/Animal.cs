﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalLibrary
{
    public abstract class Animal:IComparable<Animal>
    //     ^^^^^^^^ Abstract ~ MustInherit Cannot be instantiated, only inherited from
    {
        public string Name { get; set; } //= "Anonymous";
        //private int limbCount = 4;
        public string Colour { get; set; } //= "Brown";
        public int Health { get; set; } //= 100;
        public static int Counter { get; set; } //static ~ Shared

        protected string secret = "This is a secret";

        public Animal(string name = "Anonymous", string colour = "Brown", int limbCount = 4)
        {
            Name = name;
            Colour = colour;
            LimbCount = limbCount;
            Counter++;
        }

        static Animal()
        {
            Counter = 0;
        }


        private int limbCount = 4;

        public int LimbCount
        {
            get
            {
                return limbCount;
            }
            set
            {
                if (value < 0)
                {
                    value = 0;
                }
                else if (value > 100)
                {
                    value = 100;
                }
                limbCount = value;
            }
        }


        public virtual string Eat(string food)
        //     ^^^^^^^ Overridable
        {
            return $"I'm a {Colour} animal called {Name} using some of my {LimbCount} limbs to eat {food}";
        }

        public abstract string Move(int distance, string direction = "up");
        //     ^^^^^^^^ Abstract ~ MustOverride No implementation here, must be implemented in the child class


        public static string GetCounter()
        {
            return $"{Counter} animals have been created so far!";
        }

        public int CompareTo(Animal? other)
        {
            return this.LimbCount - other.LimbCount;
        }

        private static IComparer<Animal> nameComparer = null;

        public static IComparer<Animal> NameComparer
        {
            get
            {
                if (nameComparer == null)
                {
                    nameComparer = new AnimalNameComparer();
                }
                return nameComparer;
            }
        }

        private class AnimalNameComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Name.CompareTo(y.Name);
            }
        }

        private static IComparer<Animal> colourComparer = null;

        public static IComparer<Animal> ColourComparer
        {
            get
            {
                if (colourComparer == null)
                {
                    colourComparer = new AnimalColourComparer();
                }
                return colourComparer;
            }
        }
        private class AnimalColourComparer : IComparer<Animal>
        {
            public int Compare(Animal? x, Animal? y)
            {
                return x.Colour.CompareTo(y.Colour);
            }
        }
    }
}
