﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPFun
{
    public class Tiger: Animal
    {
        public Tiger(string name="Tigger", string colour="Black and Orange stripes", int limbCount=4, double clawLength=0.05):base(name, colour, limbCount)
        {
            ClawLength = clawLength;
        }

        public double ClawLength { get; set; }

        public string Pounce(int distance)
        {
            return $"I'm a tiger called {Name} pouncing {distance} metres!";
        }

        public override string Eat(string food)
        {
            return $"I'm a tiger called {Name} ripping the flesh off {food}!";
        }
    }
}
