﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPFun
{
    internal class Otter:Animal
    {
        public Otter(string name = "Olly", string colour = "Brown", int limbCount = 4, double whiskerLength = 0.1) : base(name, colour, limbCount)
        {
            WhiskerLength = whiskerLength;
            secret = "Not so secret";
        }
        public double WhiskerLength { get; set; }
        public string Swim(int distance)
        {
            return $"I'm an otter called {Name} swimming {distance} metres!";
        }

        public override string Eat(string food)
        {
            return $"I'm a otter called {Name} cutely holding {food} and nibbling it!";
        }
    }
}
